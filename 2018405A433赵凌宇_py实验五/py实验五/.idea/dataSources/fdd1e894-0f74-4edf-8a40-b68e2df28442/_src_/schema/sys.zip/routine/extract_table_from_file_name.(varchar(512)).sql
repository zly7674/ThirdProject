CREATE FUNCTION `extract_table_from_file_name`(`path` VARCHAR(512))
  RETURNS VARCHAR(64)
  BEGIN
    RETURN LEFT(SUBSTRING_INDEX(REPLACE(SUBSTRING_INDEX(REPLACE(path, '\', '/'), '/', -1), '@0024', '$'), '.', 1), 64);
END
/
