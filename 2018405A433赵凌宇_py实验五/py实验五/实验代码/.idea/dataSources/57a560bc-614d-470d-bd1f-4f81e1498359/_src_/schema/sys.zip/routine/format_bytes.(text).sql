CREATE FUNCTION `format_bytes`(`bytes` TEXT)
  RETURNS TEXT
  BEGIN
  IF (bytes IS NULL) THEN
    RETURN NULL;
  ELSE
    RETURN format_bytes(bytes);
  END IF;
END
    /
