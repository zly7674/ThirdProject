CREATE FUNCTION `ps_thread_id`(`in_connection_id` BIGINT UNSIGNED)
  RETURNS BIGINT UNSIGNED
  BEGIN
  IF (in_connection_id IS NULL) THEN
    RETURN ps_current_thread_id();
  ELSE
    RETURN ps_thread_id(in_connection_id);
  END IF;
END
    /
